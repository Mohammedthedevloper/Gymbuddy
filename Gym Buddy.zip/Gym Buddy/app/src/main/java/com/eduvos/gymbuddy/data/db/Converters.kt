package com.eduvos.gymbuddy.data.db
import androidx.room.TypeConverter
class Converters {
    @TypeConverter fun fromFloat(value: Float?): String? = value?.toString()
    @TypeConverter fun toFloat(value: String?): Float? = value?.toFloatOrNull()
}
