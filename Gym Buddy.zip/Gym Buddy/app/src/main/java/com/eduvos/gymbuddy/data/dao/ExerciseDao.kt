package com.eduvos.gymbuddy.data.dao
import androidx.room.*
import com.eduvos.gymbuddy.data.entity.Exercise
@Dao
interface ExerciseDao {
    @Insert suspend fun insert(exercise: Exercise): Long
    @Query("SELECT * FROM Exercise WHERE userId = :userId AND bodyPart = :bodyPart ORDER BY name")
    suspend fun byBodyPart(userId: Long, bodyPart: String): List<Exercise>
    @Query("SELECT * FROM Exercise WHERE userId = :userId ORDER BY bodyPart, name")
    suspend fun all(userId: Long): List<Exercise>



    @Query("SELECT * FROM Exercise WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<Exercise>


}
