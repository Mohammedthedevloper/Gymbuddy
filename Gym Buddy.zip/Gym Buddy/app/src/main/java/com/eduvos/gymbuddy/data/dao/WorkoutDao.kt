package com.eduvos.gymbuddy.data.dao
import androidx.room.*
import com.eduvos.gymbuddy.data.entity.SetEntry
import com.eduvos.gymbuddy.data.entity.WorkoutRating
import com.eduvos.gymbuddy.data.entity.WorkoutSession
@Dao
interface WorkoutDao {
    @Insert suspend fun insertSession(session: WorkoutSession): Long
    @Insert suspend fun insertSet(set: SetEntry): Long
    @Insert suspend fun insertRating(rating: WorkoutRating): Long
    @Query("SELECT COUNT(DISTINCT date(substr(dateTimeIso,1,10))) FROM WorkoutSession WHERE userId=:userId AND date(dateTimeIso) BETWEEN date(:startIso) AND date(:endIso)")
    suspend fun trainingDaysInRange(userId: Long, startIso: String, endIso: String): Int
    @Query("SELECT IFNULL(SUM(reps),0) FROM SetEntry WHERE sessionId IN (SELECT id FROM WorkoutSession WHERE userId = :userId AND date(dateTimeIso) BETWEEN date(:startIso) AND date(:endIso))")
    suspend fun totalRepsInRange(userId: Long, startIso: String, endIso: String): Int
    @Query("SELECT COUNT(*) FROM SetEntry WHERE sessionId IN (SELECT id FROM WorkoutSession WHERE userId = :userId AND date(dateTimeIso) BETWEEN date(:startIso) AND date(:endIso))")
    suspend fun totalSetsInRange(userId: Long, startIso: String, endIso: String): Int
    @Query("SELECT * FROM WorkoutSession WHERE userId = :userId ORDER BY dateTimeIso DESC")
    suspend fun sessions(userId: Long): List<WorkoutSession>
    @Query("SELECT * FROM SetEntry WHERE sessionId = :sessionId")
    suspend fun setsForSession(sessionId: Long): List<SetEntry>


    @Query("SELECT * FROM WorkoutSession WHERE userId = :userId AND date(dateTimeIso) BETWEEN :startIso AND :endIso")
    suspend fun sessionsInRange(
        userId: Long,
        startIso: String,
        endIso: String
    ): List<WorkoutSession>

    @Query("SELECT * FROM SetEntry WHERE sessionId IN (:sessionIds)")
    suspend fun setsForSessions(sessionIds: List<Long>): List<SetEntry>


}
