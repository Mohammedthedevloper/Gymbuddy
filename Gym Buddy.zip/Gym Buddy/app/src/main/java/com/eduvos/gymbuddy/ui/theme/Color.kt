package com.eduvos.gymbuddy.ui.theme
