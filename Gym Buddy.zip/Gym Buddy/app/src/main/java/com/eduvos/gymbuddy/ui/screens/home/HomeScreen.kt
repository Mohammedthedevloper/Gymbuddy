@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.eduvos.gymbuddy.ui.screens.home

import android.annotation.SuppressLint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eduvos.gymbuddy.data.entity.WeightEntry
import com.eduvos.gymbuddy.repo.WorkoutRepository
import com.eduvos.gymbuddy.session.SessionManager
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.max

/**
 * Visual home dashboard with:
 *  - Quick actions
 *  - Weekly stats (days, sets, reps)
 *  - Weight sparkline
 *  - Helpful links
 *  - Logout button fixed in bottom bar (always visible)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repo: WorkoutRepository,
    onAddWorkout: () -> Unit,
    onTimer: () -> Unit,
    onWeekly: () -> Unit,
    onMax: () -> Unit,
    onAllData: () -> Unit,
    onLoggedOut: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current

    // ----- State -----
    var userId by remember { mutableStateOf(1L) }
    var days by remember { mutableStateOf(0) }
    var sets by remember { mutableStateOf(0) }
    var reps by remember { mutableStateOf(0) }
    var weightSeries by remember { mutableStateOf<List<WeightEntry>>(emptyList()) }
    var lastWeighIn by remember { mutableStateOf<WeightEntry?>(null) }

    val end = remember { LocalDate.now() }
    val start = remember { end.minusDays(6) }

    // Observe session user id
    LaunchedEffect(Unit) {
        SessionManager.userIdFlow(ctx).collect { id -> userId = id ?: 1L }
    }

    // Load weekly stats + weight series
    LaunchedEffect(userId, start, end) {
        val (d, s, r) = repo.weeklyReport(userId, start.toString(), end.toString())
        days = d; sets = s; reps = r

        val all = repo.weightSeries(userId).sortedBy { it.dateIso }
        weightSeries = if (all.size > 8) all.takeLast(8) else all
        lastWeighIn = all.lastOrNull()
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("GymBuddy", style = MaterialTheme.typography.headlineSmall) })
        },
        bottomBar = {
            Surface(tonalElevation = 2.dp) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .navigationBarsPadding()
                ) {
                    OutlinedButton(
                        onClick = { scope.launch { onLoggedOut() } },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Log out") }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- Quick Actions ----
            Text("Quick actions", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton("Add Workout", onAddWorkout, Modifier.weight(1f))
                ActionButton("Timer", onTimer, Modifier.weight(1f))
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton("Weekly Report", onWeekly, Modifier.weight(1f))
                ActionButton("Max Tracker", onMax, Modifier.weight(1f))
            }
            ActionButton("All Data", onAllData, Modifier.fillMaxWidth())

            // ---- Weekly Stats ----
            StatsCard(
                title = "This week",
                subtitle = "${prettyDate(start)} to ${prettyDate(end)}",
                items = listOf(
                    StatItem("Days", days.toString()),
                    StatItem("Sets", sets.toString()),
                    StatItem("Reps", reps.toString())
                )
            )

            // ---- Weight Sparkline ----
            WeightCard(entries = weightSeries, last = lastWeighIn)

            // ---- Helpful Links ----
            HelpLinksCard { url -> uri.openUri(url) }

            // No weighted Spacer here: content scrolls; logout lives in bottom bar
            Spacer(Modifier.height(8.dp))
        }
    }
}

/* ------------------------- UI building blocks ------------------------- */

@Composable
private fun ActionButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.height(46.dp)
    ) {
        Text(text, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

data class StatItem(val label: String, val value: String)

@Composable
private fun StatsCard(
    title: String,
    subtitle: String? = null,
    items: List<StatItem>
) {
    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items.forEach { s ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                        Text(s.value, style = MaterialTheme.typography.headlineSmall)
                        Text(
                            s.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HelpLinksCard(onOpen: (String) -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Helpful resources", style = MaterialTheme.typography.titleMedium)
            AssistChipRow(
                listOf(
                    "MuscleWiki" to "https://musclewiki.com/",
                    "StrongLifts 5x5" to "https://stronglifts.com/5x5/",
                    "ExRx Exercise DB" to "https://exrx.net/Lists/Directory",
                    "r/Fitness Wiki" to "https://www.reddit.com/r/Fitness/wiki/"
                ),
                onOpen = onOpen
            )
        }
    }
}

@Composable
private fun AssistChipRow(links: List<Pair<String, String>>, onOpen: (String) -> Unit) {
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        links.forEach { (label, url) ->
            AssistChip(onClick = { onOpen(url) }, label = { Text(label) })
        }
    }
}

/* ------------------------- Weight chart card ------------------------- */

@Composable
private fun WeightCard(entries: List<WeightEntry>, last: WeightEntry?) {
    val axisColor = MaterialTheme.colorScheme.outlineVariant
    val lineColor = MaterialTheme.colorScheme.primary

    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Body weight", style = MaterialTheme.typography.titleMedium)
                val lastStr = last?.let { "${it.weightKg} kg  •  ${prettyShortDate(it.dateIso)}" }
                    ?: "No weigh-ins yet"
                Text(lastStr, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                contentAlignment = Alignment.Center
            ) {
                if (entries.size < 2) {
                    Text("Add weekly weigh-ins to see your trend.")
                } else {
                    WeightSparkline(
                        points = entries.map { it.weightKg },
                        axisColor = axisColor,
                        lineColor = lineColor
                    )
                }
            }
        }
    }
}

/**
 * Minimal sparkline drawn with Canvas; theme colors passed in as params
 * to avoid @Composable reads inside Canvas.
 */
@Composable
private fun WeightSparkline(
    points: List<Float>,
    axisColor: androidx.compose.ui.graphics.Color,
    lineColor: androidx.compose.ui.graphics.Color
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        val minV = points.minOrNull() ?: 0f
        val maxV = points.maxOrNull() ?: 1f
        val span = max(1e-3f, maxV - minV)

        // padding inside chart
        val topBotPad = h * 0.1f
        val usableH = h - topBotPad * 2

        val dx = if (points.size <= 1) 0f else w / (points.size - 1)

        // optional baseline
        // drawLine(axisColor, Offset(0f, h - topBotPad), Offset(w, h - topBotPad), 2f)

        var prev: Offset? = null
        points.forEachIndexed { i, v ->
            val x = i * dx
            val y = h - ((v - minV) / span) * usableH - topBotPad
            val cur = Offset(x, y)
            prev?.let { p -> drawLine(color = lineColor, start = p, end = cur, strokeWidth = 6f) }
            prev = cur
        }
        prev?.let { drawCircle(color = lineColor, radius = 8f, center = it) }
    }
}

/* ------------------------- Helpers ------------------------- */

private fun prettyDate(d: LocalDate): String =
    d.format(DateTimeFormatter.ofPattern("dd MMM yyyy"))

@SuppressLint("NewApi")
private fun prettyShortDate(iso: String): String = runCatching {
    LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("dd MMM"))
}.getOrDefault(iso)
