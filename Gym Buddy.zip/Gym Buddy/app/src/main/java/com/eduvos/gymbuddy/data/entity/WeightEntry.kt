package com.eduvos.gymbuddy.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "WeightEntry")
data class WeightEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val dateIso: String,   // yyyy-MM-dd
    val weightKg: Float
)
