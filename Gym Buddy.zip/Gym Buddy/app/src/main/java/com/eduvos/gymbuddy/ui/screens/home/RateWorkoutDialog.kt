package com.eduvos.gymbuddy.ui.screens.home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp

@Composable
fun RateWorkoutDialog(onDismiss: ()->Unit, onSubmit: (Int, String?)->Unit = {_,_->}) {
    var rating by remember { mutableStateOf(3f) }
    var note by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        Card {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Rate today's workout (1–5)")
                Slider(value = rating, onValueChange = { rating = it }, valueRange = 1f..5f, steps = 3)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Add Note (optional)") })
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End){
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onSubmit(rating.toInt(), note.ifBlank { null }); onDismiss() }) { Text("Save") }
                }
            }
        }
    }
}
