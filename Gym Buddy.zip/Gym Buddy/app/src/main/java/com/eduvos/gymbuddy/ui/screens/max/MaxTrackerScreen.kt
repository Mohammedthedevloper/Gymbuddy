package com.eduvos.gymbuddy.ui.screens.max

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.SaveOutcome
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun MaxTrackerScreen(repo: WorkoutRepository) {
    val scope = rememberCoroutineScope()

    var exercise by remember { mutableStateOf("") }
    var reps by remember { mutableStateOf("1") }
    var weight by remember { mutableStateOf("0.0") }

    var showHistory by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(emptyList<com.eduvos.gymbuddy.data.entity.MaxHistory>()) }

    // Dialog outcome
    var outcome by remember { mutableStateOf<SaveOutcome?>(null) }

    val fmt = remember { DateTimeFormatter.ofPattern("dd MMM yyyy • HH:mm") }

    // Popup dialog when outcome is set
    if (outcome != null) {
        val (title, message) = when (outcome) {
            SaveOutcome.SAVED_NEW -> "Saved" to "Your max was saved."
            SaveOutcome.UPDATED_BETTER -> "Updated" to "New personal record saved!"
            SaveOutcome.NO_CHANGE -> "Saved" to "Recorded, but your best max remains the same."
            null -> "" to ""
        }
        AlertDialog(
            onDismissRequest = { outcome = null },
            confirmButton = {
                TextButton(onClick = { outcome = null }) { Text("OK") }
            },
            title = { Text(title) },
            text = { Text(message) }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Max Tracker", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = exercise,
            onValueChange = { exercise = it },
            label = { Text("Exercise") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = reps,
            onValueChange = { reps = it.filter { ch -> ch.isDigit() } },
            label = { Text("Rep range (e.g. 1)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = weight,
            onValueChange = { weight = it.filter { ch -> ch.isDigit() || ch == '.' } },
            label = { Text("Weight (kg)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val r = reps.toIntOrNull() ?: 1
                    val w = weight.toFloatOrNull() ?: 0f
                    scope.launch {
                        // TODO: replace hardcoded userId = 1 with SessionManager.getUserId(context)
                        val result = repo.upsertMax(userId = 1, exercise = exercise.trim(), repRange = r, weight = w)
                        outcome = result  // shows the popup
                        if (showHistory) {
                            history = repo.maxHistory(userId = 1) // refresh if visible
                        }
                    }
                }
            ) { Text("Save / Update") }

            OutlinedButton(
                onClick = {
                    showHistory = !showHistory
                    if (showHistory) {
                        scope.launch { history = repo.maxHistory(userId = 1) }
                    }
                }
            ) { Text(if (showHistory) "Hide history" else "View history") }
        }

        if (showHistory) {
            Spacer(Modifier.height(16.dp))
            Text("Previous max lifts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            if (history.isEmpty()) {
                Text("No entries yet.")
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(bottom = 40.dp)
                ) {
                    items(history) { h ->
                        ListItem(
                            headlineContent = { Text("${h.exerciseName} — ${h.weight} kg") },
                            supportingContent = {
                                val ts = runCatching { LocalDateTime.parse(h.recordedAtIso) }.getOrNull()
                                val whenText = ts?.format(fmt) ?: h.recordedAtIso
                                Text("Reps: ${h.repRange}  •  $whenText")
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }
}
