package com.eduvos.gymbuddy.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.launch
class WorkoutViewModel(private val repo: WorkoutRepository): ViewModel() {
    fun startSession(userId: Long, onId: (Long)->Unit) = viewModelScope.launch { onId(repo.startSession(userId)) }
    fun addExercise(userId: Long, name: String, part: String, onId: (Long)->Unit) = viewModelScope.launch { onId(repo.addExercise(userId, name, part)) }
    fun addSet(sessionId: Long, exerciseId: Long, reps: Int, weight: Float) = viewModelScope.launch { repo.addSet(sessionId, exerciseId, reps, weight) }
    fun rate(sessionId: Long, rating: Int, note: String?) = viewModelScope.launch { repo.rateSession(sessionId, rating, note) }
    fun upsertMax(userId: Long, ex: String, rep: Int, w: Float) = viewModelScope.launch { repo.upsertMax(userId, ex, rep, w) }
}
