package com.eduvos.gymbuddy.ui.screens.data
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.WorkoutRepository
import com.eduvos.gymbuddy.data.entity.WorkoutSession
@Composable
fun AllDataScreen(repo: WorkoutRepository) {
    var sessions by remember { mutableStateOf<List<WorkoutSession>>(emptyList()) }
    LaunchedEffect(Unit) { sessions = repo.sessions(1) }
    LazyColumn {
        items(sessions) { s ->
            ElevatedCard(modifier = Modifier.padding(12.dp)) {
                ListItem(headlineContent = { Text("Session ${s.id}") }, supportingContent = { Text(s.dateTimeIso) })
            }
        }
    }
}
