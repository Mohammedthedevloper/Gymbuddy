package com.eduvos.gymbuddy.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.eduvos.gymbuddy.data.dao.*
import com.eduvos.gymbuddy.data.entity.*

@Database(
    entities = [
        User::class,
        Exercise::class,
        WorkoutSession::class,
        SetEntry::class,
        WorkoutRating::class,
        MaxRecord::class,
        MaxHistory::class,
        WeightEntry::class
    ],
    version = 4,                 // ⬆️ bump for isVerified column
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun exerciseDao(): ExerciseDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun maxDao(): MaxDao
    abstract fun maxHistoryDao(): MaxHistoryDao
    abstract fun weightDao(): WeightDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gymbuddy.db"
                )
                    // Dev-friendly: nukes & rebuilds schema on version bump, if yall want to change data tablets etc
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
