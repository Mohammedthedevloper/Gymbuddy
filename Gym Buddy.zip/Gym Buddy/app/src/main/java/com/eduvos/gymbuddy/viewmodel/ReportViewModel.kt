package com.eduvos.gymbuddy.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
class ReportViewModel(private val repo: WorkoutRepository): ViewModel() {
    private val _report = MutableStateFlow(Triple(0,0,0))
    val report: StateFlow<Triple<Int,Int,Int>> = _report
    fun loadWeekly(userId: Long, startIso: String, endIso: String) {
        viewModelScope.launch { _report.value = repo.weeklyReport(userId, startIso, endIso) }
    }
}
