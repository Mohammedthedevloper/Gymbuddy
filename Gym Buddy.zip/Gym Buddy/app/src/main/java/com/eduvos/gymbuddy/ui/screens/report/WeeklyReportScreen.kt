package com.eduvos.gymbuddy.ui.screens.report

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.WorkoutRepository
import com.eduvos.gymbuddy.ui.util.ShareUtil
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun WeeklyReportScreen(repo: WorkoutRepository) {
    // Show the last 7 days (inclusive)
    var start by remember { mutableStateOf(LocalDate.now().minusDays(6)) }
    val end = remember { LocalDate.now() }

    var days by remember { mutableStateOf(0) }
    var sets by remember { mutableStateOf(0) }
    var reps by remember { mutableStateOf(0) }

    val ctx = LocalContext.current
    val displayFmt = remember { DateTimeFormatter.ofPattern("dd MMM yyyy") } // e.g. 20 Oct 2025

    // Load from DB whenever the start date changes
    LaunchedEffect(start) {
        val (d, s, r) = repo.weeklyReport(
            /* TODO: replace 1 with current userId from SessionManager when wired */
            userId = 1,
            startIso = start.toString(),
            endIso = end.toString()
        )
        days = d
        sets = s
        reps = r
    }

    Column(Modifier.padding(16.dp)) {
        Text("Weekly Report", style = MaterialTheme.typography.headlineMedium)
        Text("${start.format(displayFmt)} to ${end.format(displayFmt)}")

        Spacer(Modifier.height(8.dp))
        Text("Training days: $days")
        Text("Total sets: $sets")
        Text("Total reps: $reps")

        Spacer(Modifier.height(12.dp))

        Button(onClick = {
            val csv = buildString {
                appendLine("Metric,Value")
                appendLine("Start Date,${start}")
                appendLine("End Date,${end}")
                appendLine("Training Days,$days")
                appendLine("Total Sets,$sets")
                appendLine("Total Reps,$reps")
            }
            // ✅ Correct interpolation for file name
            ShareUtil.shareCsv(ctx, "weekly_report_${start}_$end.csv", csv)
        }) {
            Text("Export CSV")
        }
    }
}
