package com.eduvos.gymbuddy.ui.screens.admin

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.data.db.AppDatabase
import com.eduvos.gymbuddy.data.entity.User
import com.eduvos.gymbuddy.repo.AdminRepository
import com.eduvos.gymbuddy.repo.AuthRepository
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

/**
 * Admin screen with:
 *  - Password gate ("moe123$/0")
 *  - Users list with dates formatted nicely
 *  - Verify / Unverify, Block / Unblock, Delete
 */
@Composable
fun AdminScreen(authRepo: AuthRepository) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val adminRepo = remember { AdminRepository(AppDatabase.get(ctx).userDao()) }

    var authed by remember { mutableStateOf(false) }
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    if (!authed) {
        Column(Modifier.padding(16.dp)) {
            Text("Admin Access", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pw,
                onValueChange = { pw = it },
                label = { Text("Enter admin password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            if (error != null) {
                Spacer(Modifier.height(6.dp))
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    if (pw == "moe123$/0") {
                        authed = true
                        error = null
                    } else {
                        error = "Incorrect password"
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Unlock") }
        }
        return
    }

    // -- Date formatter (short date + short time) --
    val fmt = remember { DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM, FormatStyle.SHORT) }

    fun pretty(iso: String?): String {
        if (iso.isNullOrBlank()) return "—"
        return runCatching { LocalDateTime.parse(iso) }
            .map { it.format(fmt) }
            .getOrElse { iso }
    }

    var users by remember { mutableStateOf<List<User>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        users = adminRepo.users()
    }

    Column(Modifier.padding(16.dp)) {
        Text("Admin — Users", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))

        if (users.isEmpty()) {
            Text("No users yet.")
            return@Column
        }

        LazyColumn(
            contentPadding = PaddingValues(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(users, key = { it.id }) { u ->
                ElevatedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${u.name} (${u.email})", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(2.dp))
                        Text("Created: ${pretty(u.createdAtIso)}")
                        Text("Last active: ${pretty(u.lastActiveIso)}")
                        Text("Role: ${if (u.isAdmin) "Admin" else "User"}  ·  Blocked: ${u.isBlocked}  ·  Verified: ${u.isVerified}")

                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Verify / Unverify
                            Button(
                                onClick = {
                                    scope.launch {
                                        if (u.isVerified) adminRepo.unverify(u.id) else adminRepo.verify(u.id)
                                        users = adminRepo.users()
                                    }
                                }
                            ) { Text(if (u.isVerified) "Unverify" else "Verify") }

                            // Block / Unblock
                            Button(
                                onClick = {
                                    scope.launch {
                                        if (u.isBlocked) adminRepo.unblock(u.id) else adminRepo.block(u.id)
                                        users = adminRepo.users()
                                    }
                                },
                                enabled = true
                            ) { Text(if (u.isBlocked) "Unblock" else "Block") }

                            // Delete
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        adminRepo.delete(u.id)
                                        users = adminRepo.users()
                                    }
                                }
                            ) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
