package com.eduvos.gymbuddy.ui.screens.workout

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalTime

@Composable
fun TimerScreen(repo: WorkoutRepository) {
    val scope = rememberCoroutineScope()

    // countdown state
    var seconds by remember { mutableStateOf(60) }          // default 60s
    var initial by remember { mutableStateOf(60) }          // store what we started with
    var running by remember { mutableStateOf(false) }
    var sessionId by remember { mutableStateOf<Long?>(null) } // created on first Start

    // ticking loop
    LaunchedEffect(running) {
        while (running) {
            delay(1000)
            if (seconds > 0) {
                seconds--
            } else {
                running = false
                // when a countdown completes, record a note on today's session
                sessionId?.let { sid ->
                    scope.launch {
                        repo.rateSession(
                            sessionId = sid,
                            rating = 0,
                            note = "Timer completed: ${initial}s at ${LocalTime.now()}"
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Workout Timer", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        // BIG counter
        Text(
            text = formatSeconds(seconds),
            style = MaterialTheme.typography.displayLarge
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    // ensure today has a session (this “saves the data for the session/day”)
                    if (sessionId == null) {
                        scope.launch {
                            sessionId = repo.startSession(userId = 1) // TODO: use SessionManager userId
                        }
                    }
                    if (seconds == 0) seconds = initial
                    running = true
                }
            ) { Text("Start") }

            Button(onClick = { running = false }) { Text("Pause") }

            OutlinedButton(onClick = {
                running = false
                seconds = initial
            }) { Text("Reset") }
        }

        Spacer(Modifier.height(16.dp))
        Text("Rest presets")
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(60, 90, 120).forEach { preset ->
                OutlinedButton(onClick = {
                    initial = preset
                    seconds = preset
                    // pressing a preset starts immediately and records session if needed
                    if (sessionId == null) {
                        scope.launch { sessionId = repo.startSession(userId = 1) }
                    }
                    running = true
                }) { Text("${preset} s") }
            }
        }
    }
}

private fun formatSeconds(total: Int): String {
    val m = total / 60
    val s = total % 60
    return "%02d:%02d".format(m, s)
}
