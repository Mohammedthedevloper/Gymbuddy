package com.eduvos.gymbuddy.ui.screens.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.AuthRepository
import com.eduvos.gymbuddy.viewmodel.AuthViewModel

@Composable
fun SignUpScreen(repo: AuthRepository, onSignUpComplete: () -> Unit) {
    val vm = remember { AuthViewModel(repo) }

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val isEmailValid = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    val isStrongPassword = password.length >= 8 &&
            password.any { it.isUpperCase() } &&
            password.any { it.isLowerCase() } &&
            password.any { it.isDigit() } &&
            password.any { !it.isLetterOrDigit() }
    val isNameValid = name.trim().length >= 2

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Create your GymBuddy account",
            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Full name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(10.dp))

        // Inline validation hints
        if (name.isNotBlank() && !isNameValid) {
            Text("⚠ Please enter your full name.", color = MaterialTheme.colorScheme.error)
        }
        if (email.isNotBlank() && !isEmailValid) {
            Text("⚠ Please enter a valid email address.", color = MaterialTheme.colorScheme.error)
        }
        if (password.isNotBlank() && !isStrongPassword) {
            Text(
                "⚠ Password must be 8+ chars and include upper, lower, number, and symbol.",
                color = MaterialTheme.colorScheme.error
            )
        }
        if (password.isNotBlank() && confirmPassword.isNotBlank() && password != confirmPassword) {
            Text("⚠ Passwords do not match.", color = MaterialTheme.colorScheme.error)
        }

        val vmError by vm.error.collectAsState(null)
        if (vmError != null) {
            Text(vmError!!, color = MaterialTheme.colorScheme.error)
        }
        if (error != null) {
            Text(error!!, color = MaterialTheme.colorScheme.error)
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                when {
                    !isNameValid -> error = "Please enter your full name."
                    !isEmailValid -> error = "Invalid email format."
                    !isStrongPassword -> error = "Password too weak."
                    password != confirmPassword -> error = "Passwords do not match."
                    else -> {
                        error = null
                        vm.signUp(name, email, password) {
                            onSignUpComplete()
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = name.isNotBlank() && email.isNotBlank() && password.isNotBlank() && confirmPassword.isNotBlank()
        ) {
            Text("Sign Up")
        }
    }
}
