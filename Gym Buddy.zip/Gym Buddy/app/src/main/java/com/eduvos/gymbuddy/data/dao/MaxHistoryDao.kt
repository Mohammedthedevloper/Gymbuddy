package com.eduvos.gymbuddy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.eduvos.gymbuddy.data.entity.MaxHistory

@Dao
interface MaxHistoryDao {
    @Insert
    suspend fun insert(h: MaxHistory): Long

    @Query("SELECT * FROM MaxHistory WHERE userId = :userId ORDER BY recordedAtIso DESC")
    suspend fun history(userId: Long): List<MaxHistory>
}
