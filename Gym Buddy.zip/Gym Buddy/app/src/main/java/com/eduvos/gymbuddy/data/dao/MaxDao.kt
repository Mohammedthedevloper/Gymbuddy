package com.eduvos.gymbuddy.data.dao
import androidx.room.*
import com.eduvos.gymbuddy.data.entity.MaxRecord
@Dao
interface MaxDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(max: MaxRecord): Long
    @Query("SELECT * FROM MaxRecord WHERE userId = :userId ORDER BY exerciseName, repRange")
    suspend fun all(userId: Long): List<MaxRecord>
    @Query("SELECT * FROM MaxRecord WHERE userId=:userId AND exerciseName=:exercise AND repRange=:repRange LIMIT 1")
    suspend fun find(userId: Long, exercise: String, repRange: Int): MaxRecord?
}
