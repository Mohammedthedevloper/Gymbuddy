package com.eduvos.gymbuddy.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduvos.gymbuddy.repo.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
class AuthViewModel(private val repo: AuthRepository): ViewModel() {
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    fun signUp(name: String, email: String, password: String, onOk: (Long)->Unit) {
        viewModelScope.launch {
            repo.signUp(name, email, password).onSuccess(onOk).onFailure { _error.value = it.message }
        }
    }
    fun login(email: String, password: String, onOk: (Long)->Unit) {
        viewModelScope.launch {
            repo.login(email, password).onSuccess { onOk(it.id) }.onFailure { _error.value = it.message }
        }
    }
}
