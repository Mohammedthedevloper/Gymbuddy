package com.eduvos.gymbuddy.repo

import com.eduvos.gymbuddy.data.dao.UserDao
import com.eduvos.gymbuddy.data.entity.User
import com.eduvos.gymbuddy.security.PasswordHasher
import java.time.LocalDateTime

class AuthRepository(private val userDao: UserDao) {

    /**
     * Register a new user with hashed password and timestamp.
     */
    suspend fun signUp(name: String, email: String, password: String): Result<Long> {
        val (hash, salt) = PasswordHasher.hash(password)
        val user = User(
            name = name,
            email = email,
            passwordHash = hash,
            passwordSalt = salt,
            createdAtIso = LocalDateTime.now().toString(), // ✅ REQUIRED FIELD
            lastActiveIso = null,
            isAdmin = false,
            isBlocked = false,
            isVerified = false
        )
        return runCatching { userDao.insert(user) }
    }

    /**
     * Validate login credentials, block status, and verification.
     */
    suspend fun login(email: String, password: String): Result<User> = runCatching {
        val user = userDao.byEmail(email) ?: throw Exception("No account found with that email")
        if (user.isBlocked) throw Exception("Your account has been blocked by admin")
        if (!user.isVerified && !user.isAdmin) throw Exception("Your account has not been verified yet")

        val ok = PasswordHasher.verify(password, user.passwordHash, user.passwordSalt)
        if (!ok) throw Exception("Incorrect password")

        // Update last-active timestamp
        userDao.setLastActive(user.id, LocalDateTime.now().toString())
        user
    }
}
