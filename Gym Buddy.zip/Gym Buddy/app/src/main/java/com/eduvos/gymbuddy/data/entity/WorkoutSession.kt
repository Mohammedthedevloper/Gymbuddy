package com.eduvos.gymbuddy.data.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
data class WorkoutSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val dateTimeIso: String
)
