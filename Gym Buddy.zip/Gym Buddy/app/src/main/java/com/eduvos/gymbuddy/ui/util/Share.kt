package com.eduvos.gymbuddy.ui.util
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
object ShareUtil {
    fun shareCsv(context: Context, fileName: String, csvContent: String) {
        val file = File(context.cacheDir, fileName)
        file.writeText(csvContent)
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share weekly report"))
    }
}
