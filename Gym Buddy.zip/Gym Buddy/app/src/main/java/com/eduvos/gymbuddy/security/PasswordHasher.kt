package com.eduvos.gymbuddy.security

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordHasher {
    private const val ITERATIONS = 96_000
    private const val KEY_LENGTH = 256

    fun hash(password: String, salt: ByteArray = newSalt()): Pair<String, String> {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val res = skf.generateSecret(spec).encoded
        val hashB64 = Base64.encodeToString(res, Base64.NO_WRAP)
        val saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP)
        return hashB64 to saltB64
    }

    fun verify(password: String, hashB64: String, saltB64: String): Boolean {
        val salt = Base64.decode(saltB64, Base64.DEFAULT)
        val (calc, _) = hash(password, salt)
        return constantTimeEquals(calc, hashB64)
    }

    private fun newSalt(): ByteArray = ByteArray(16).also { SecureRandom().nextBytes(it) }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        val aBytes = a.toByteArray()
        val bBytes = b.toByteArray()
        if (aBytes.size != bBytes.size) return false
        var r = 0
        for (i in aBytes.indices) {
            r = r or (aBytes[i].toInt() xor bBytes[i].toInt())
        }
        return r == 0
    }
}
