package com.eduvos.gymbuddy.data.entity
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
data class WorkoutRating(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val rating: Int,
    val note: String? = null
)
