package com.eduvos.gymbuddy.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Core user row.
 *
 * NOTE: Added isVerified to allow admin validation.
 */
@Entity(tableName = "User")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val email: String,
    val passwordHash: String,
    val passwordSalt: String,
    val createdAtIso: String,          // ISO-8601 timestamp
    val lastActiveIso: String? = null, // ISO-8601 timestamp or null
    val isAdmin: Boolean = false,
    val isBlocked: Boolean = false,
    val isVerified: Boolean = false    // ✅ NEW: admin-approved user
)
