package com.eduvos.gymbuddy
import android.app.Application
import androidx.work.Configuration
class GymBuddyApp : Application(), Configuration.Provider {
    override val workManagerConfiguration: Configuration get() = Configuration.Builder().build()
}
