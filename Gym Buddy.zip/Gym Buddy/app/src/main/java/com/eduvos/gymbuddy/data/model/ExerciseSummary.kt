package com.eduvos.gymbuddy.data.model

data class ExerciseSummary(
    val name: String,
    val setCount: Int,
    val totalReps: Int
)
