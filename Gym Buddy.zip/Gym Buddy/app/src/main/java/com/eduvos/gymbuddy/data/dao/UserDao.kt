package com.eduvos.gymbuddy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.eduvos.gymbuddy.data.entity.User

@Dao
interface UserDao {

    @Insert
    suspend fun insert(u: User): Long

    @Update
    suspend fun update(u: User)

    @Query("SELECT * FROM User WHERE email = :email LIMIT 1")
    suspend fun byEmail(email: String): User?

    @Query("SELECT * FROM User WHERE id = :id")
    suspend fun byId(id: Long): User?

    // ---- Admin lists ----
    @Query("SELECT * FROM User ORDER BY createdAtIso DESC")
    suspend fun all(): List<User>

    // ---- Admin actions ----
    @Query("UPDATE User SET isBlocked = 1 WHERE id = :id")
    suspend fun block(id: Long)

    @Query("UPDATE User SET isBlocked = 0 WHERE id = :id")
    suspend fun unblock(id: Long)

    @Query("DELETE FROM User WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("UPDATE User SET isVerified = 1 WHERE id = :id")
    suspend fun verify(id: Long)

    @Query("UPDATE User SET isVerified = 0 WHERE id = :id")
    suspend fun unverify(id: Long)

    // Optional helper for last-active stamp
    @Query("UPDATE User SET lastActiveIso = :iso WHERE id = :id")
    suspend fun setLastActive(id: Long, iso: String)
}
