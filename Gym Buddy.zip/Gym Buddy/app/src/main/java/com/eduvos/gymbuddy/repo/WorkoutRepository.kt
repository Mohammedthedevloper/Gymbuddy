package com.eduvos.gymbuddy.repo

import com.eduvos.gymbuddy.data.dao.ExerciseDao
import com.eduvos.gymbuddy.data.dao.MaxDao
import com.eduvos.gymbuddy.data.dao.MaxHistoryDao
import com.eduvos.gymbuddy.data.dao.WeightDao
import com.eduvos.gymbuddy.data.dao.WorkoutDao
import com.eduvos.gymbuddy.data.entity.*
import com.eduvos.gymbuddy.data.model.ExerciseSummary
import java.time.LocalDateTime

enum class SaveOutcome { SAVED_NEW, UPDATED_BETTER, NO_CHANGE }

class WorkoutRepository(
    private val exerciseDao: ExerciseDao,
    private val workoutDao: WorkoutDao,
    private val maxDao: MaxDao,
    private val maxHistoryDao: MaxHistoryDao,
    private val weightDao: WeightDao
) {
    // ---- Sessions / logging sets -------------------------------------------------------------

    suspend fun startSession(userId: Long): Long =
        workoutDao.insertSession(
            WorkoutSession(
                userId = userId,
                dateTimeIso = LocalDateTime.now().toString()
            )
        )

    suspend fun addExercise(userId: Long, name: String, bodyPart: String): Long =
        exerciseDao.insert(Exercise(userId = userId, name = name, bodyPart = bodyPart))

    suspend fun addSet(sessionId: Long, exerciseId: Long, reps: Int, weight: Float): Long =
        workoutDao.insertSet(SetEntry(sessionId = sessionId, exerciseId = exerciseId, reps = reps, weight = weight))

    suspend fun rateSession(sessionId: Long, rating: Int, note: String?) =
        workoutDao.insertRating(WorkoutRating(sessionId = sessionId, rating = rating, note = note))

    // ---- Maxes ------------------------------------------------------------------------------
    /**
     * Called from Max Tracker screen.
     * - Updates MaxRecord
     * - Logs to MaxHistory **only when** the entry is a *new* record
     *   (SAVED_NEW or UPDATED_BETTER).
     */
    suspend fun upsertMax(
        userId: Long,
        exercise: String,
        repRange: Int,
        weight: Float
    ): SaveOutcome {
        val existing = maxDao.find(userId, exercise, repRange)
        val outcome = when {
            existing == null -> {
                maxDao.upsert(
                    MaxRecord(userId = userId, exerciseName = exercise, repRange = repRange, maxWeight = weight)
                )
                SaveOutcome.SAVED_NEW
            }
            weight > existing.maxWeight -> {
                maxDao.upsert(existing.copy(maxWeight = weight))
                SaveOutcome.UPDATED_BETTER
            }
            else -> SaveOutcome.NO_CHANGE
        }

        // ✅ Only record a history row for true PRs
        if (outcome == SaveOutcome.SAVED_NEW || outcome == SaveOutcome.UPDATED_BETTER) {
            maxHistoryDao.insert(
                MaxHistory(
                    userId = userId,
                    exerciseName = exercise,
                    repRange = repRange,
                    weight = weight,
                    recordedAtIso = LocalDateTime.now().toString()
                )
            )
        }
        return outcome
    }

    /** History list shown on Max Tracker (now PRs only going forward). */
    suspend fun maxHistory(userId: Long): List<MaxHistory> = maxHistoryDao.history(userId)

    // ---- Weekly reports ---------------------------------------------------------------------

    /** Old totals-only report (still used by some screens) */
    suspend fun weeklyReport(userId: Long, startIso: String, endIso: String): Triple<Int, Int, Int> {
        val days = workoutDao.trainingDaysInRange(userId, startIso, endIso)
        val sets = workoutDao.totalSetsInRange(userId, startIso, endIso)
        val reps = workoutDao.totalRepsInRange(userId, startIso, endIso)
        return Triple(days, sets, reps)
    }

    suspend fun sessions(userId: Long): List<WorkoutSession> = workoutDao.sessions(userId)

    /** Totals + per-exercise breakdown for the week */
    suspend fun weeklyReportDetailed(
        userId: Long,
        startIso: String,
        endIso: String
    ): WeeklyReport {
        val sessions = workoutDao.sessionsInRange(userId, startIso, endIso)
        val sessionIds = sessions.map { it.id }
        if (sessionIds.isEmpty()) {
            return WeeklyReport(days = 0, totalSets = 0, totalReps = 0, breakdown = emptyList())
        }

        val sets = workoutDao.setsForSessions(sessionIds)

        val exerciseIds = sets.map { it.exerciseId }.distinct()
        val exerciseNameById = if (exerciseIds.isNotEmpty())
            exerciseDao.getByIds(exerciseIds).associate { it.id to it.name }
        else emptyMap()

        val perExercise = mutableMapOf<String, Pair<Int, Int>>() // name -> (setCount, totalReps)
        for (s in sets) {
            val name = exerciseNameById[s.exerciseId] ?: "Exercise ${s.exerciseId}"
            val cur = perExercise[name] ?: (0 to 0)
            perExercise[name] = (cur.first + 1) to (cur.second + s.reps)
        }

        val breakdown = perExercise
            .map { (name, pair) -> ExerciseSummary(name, pair.first, pair.second) }
            .sortedByDescending { it.totalReps }

        val totalSets = sets.size
        val totalReps = sets.sumOf { it.reps }
        val uniqueDays = sessions.map { it.dateTimeIso.substring(0, 10) }.distinct().size

        return WeeklyReport(days = uniqueDays, totalSets = totalSets, totalReps = totalReps, breakdown = breakdown)
    }

    // ---- Weight tracking --------------------------------------------------------------------

    suspend fun addWeighIn(userId: Long, dateIso: String, kg: Float) =
        weightDao.insert(WeightEntry(userId = userId, dateIso = dateIso, weightKg = kg))

    suspend fun weightSeries(userId: Long) = weightDao.allForUser(userId)
    suspend fun latestWeighInDate(userId: Long) = weightDao.latestDate(userId)
}

data class WeeklyReport(
    val days: Int,
    val totalSets: Int,
    val totalReps: Int,
    val breakdown: List<com.eduvos.gymbuddy.data.model.ExerciseSummary>
)
