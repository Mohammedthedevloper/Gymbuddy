package com.eduvos.gymbuddy.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.eduvos.gymbuddy.data.db.AppDatabase
import com.eduvos.gymbuddy.repo.AuthRepository
import com.eduvos.gymbuddy.repo.WorkoutRepository
import com.eduvos.gymbuddy.session.SessionManager
import com.eduvos.gymbuddy.ui.screens.admin.AdminScreen
import com.eduvos.gymbuddy.ui.screens.auth.LoginScreen
import com.eduvos.gymbuddy.ui.screens.auth.SignUpScreen
import com.eduvos.gymbuddy.ui.screens.data.AllDataScreen
import com.eduvos.gymbuddy.ui.screens.home.HomeScreen
import com.eduvos.gymbuddy.ui.screens.max.MaxTrackerScreen
import com.eduvos.gymbuddy.ui.screens.report.WeeklyReportScreen
import com.eduvos.gymbuddy.ui.screens.workout.AddWorkoutScreen
import com.eduvos.gymbuddy.ui.screens.workout.TimerScreen
import kotlinx.coroutines.launch

sealed class Route(val r: String) {
    data object Login : Route("login")
    data object SignUp : Route("signup")
    data object Home : Route("home")
    data object AddWorkout : Route("addworkout")
    data object Timer : Route("timer")
    data object Weekly : Route("weekly")
    data object Max : Route("max")
    data object AllData : Route("alldata")
    data object Admin : Route("admin")
}

@Composable
fun GymBuddyNavGraph() {
    val navController = rememberNavController()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // --- Repositories (Room DB singletons) ---
    val db = AppDatabase.get(ctx)
    val authRepo = remember { AuthRepository(db.userDao()) }
    val workoutRepo = remember {
        WorkoutRepository(
            db.exerciseDao(),
            db.workoutDao(),
            db.maxDao(),
            db.maxHistoryDao(),
            db.weightDao()
        )
    }

    // --- Decide start destination based on session ---
    var start by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        val uid = SessionManager.getUserId(ctx)
        start = if (uid != null && uid > 0) Route.Home.r else Route.Login.r
    }

    // Splash while resolving start
    if (start == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    NavHost(navController, startDestination = start!!) {

        // --- Login ---
        composable(Route.Login.r) {
            LoginScreen(
                repo = authRepo,
                onLogin = { userId ->
                    scope.launch {
                        SessionManager.setUserId(ctx, userId)
                        navController.navigate(Route.Home.r) {
                            popUpTo(Route.Login.r) { inclusive = true }
                        }
                    }
                },
                onSignUp = { navController.navigate(Route.SignUp.r) },
                onAdmin = { navController.navigate(Route.Admin.r) } // optional admin entry on welcome
            )
        }

        // --- Sign Up ---
        composable(Route.SignUp.r) {
            SignUpScreen(authRepo) { navController.popBackStack() }
        }

        // --- Home (dashboard) ---
        composable(Route.Home.r) {
            HomeScreen(
                repo = workoutRepo,
                onAddWorkout = { navController.navigate(Route.AddWorkout.r) },
                onTimer = { navController.navigate(Route.Timer.r) },
                onWeekly = { navController.navigate(Route.Weekly.r) },
                onMax = { navController.navigate(Route.Max.r) },
                onAllData = { navController.navigate(Route.AllData.r) },
                onLoggedOut = {
                    scope.launch {
                        SessionManager.setUserId(ctx, null)
                        navController.navigate(Route.Login.r) {
                            popUpTo(Route.Home.r) { inclusive = true }
                        }
                    }
                }
            )
        }

        // --- Add Workout ---
        composable(Route.AddWorkout.r) { AddWorkoutScreen(workoutRepo) }

        // --- Timer ---
        composable(Route.Timer.r) { TimerScreen(workoutRepo) }

        // --- Weekly Report ---
        composable(Route.Weekly.r) { WeeklyReportScreen(workoutRepo) }

        // --- Max Tracker ---
        composable(Route.Max.r) { MaxTrackerScreen(workoutRepo) }

        // --- All Data ---
        composable(Route.AllData.r) { AllDataScreen(workoutRepo) }

        // --- Admin (password-gated) ---
        composable(Route.Admin.r) { AdminScreen(authRepo) }
    }
}
