package com.eduvos.gymbuddy.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.eduvos.gymbuddy.data.entity.WeightEntry

@Dao
interface WeightDao {
    @Insert
    suspend fun insert(e: WeightEntry): Long

    @Query("SELECT * FROM WeightEntry WHERE userId = :userId ORDER BY dateIso ASC")
    suspend fun allForUser(userId: Long): List<WeightEntry>

    @Query("SELECT dateIso FROM WeightEntry WHERE userId = :userId ORDER BY dateIso DESC LIMIT 1")
    suspend fun latestDate(userId: Long): String?
}
