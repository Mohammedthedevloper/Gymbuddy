package com.eduvos.gymbuddy.ui.screens.workout

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.launch

@Composable
fun AddWorkoutScreen(repo: WorkoutRepository) {
    var sessionId by remember { mutableStateOf<Long?>(null) }
    var bodyPart by remember { mutableStateOf("Chest") }
    var exName by remember { mutableStateOf("") }
    var sets by remember { mutableStateOf(0) }
    var reps by remember { mutableStateOf(0) }
    var weight by remember { mutableStateOf(0f) }

    var showDone by remember { mutableStateOf(false) }
    var summary by remember { mutableStateOf("") }

    val scope = rememberCoroutineScope()

    // Dialog confirming add
    if (showDone) {
        AlertDialog(
            onDismissRequest = { showDone = false },
            confirmButton = { TextButton(onClick = { showDone = false }) { Text("OK") } },
            title = { Text("Workout added") },
            text  = { Text(summary) }
        )
    }

    Column(Modifier.padding(16.dp)) {
        Text("Add Workout", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(value = bodyPart, onValueChange = { bodyPart = it }, label = { Text("Body part") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = exName, onValueChange = { exName = it }, label = { Text("Exercise name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = sets.toString(), onValueChange = { sets = it.toIntOrNull() ?: 0 }, label = { Text("Sets") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = reps.toString(), onValueChange = { reps = it.toIntOrNull() ?: 0 }, label = { Text("Reps per set") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = weight.toString(), onValueChange = { weight = it.toFloatOrNull() ?: 0f }, label = { Text("Weight (kg)") }, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(8.dp))

        Button(
            onClick = {
                scope.launch {
                    // Start/continue session
                    if (sessionId == null) sessionId = repo.startSession(1)

                    // Add the exercise once and the sets
                    val exId = repo.addExercise(1, exName.trim(), bodyPart.trim())
                    repeat(sets) { repo.addSet(sessionId!!, exId, reps, weight) }

                    // ⚠️ IMPORTANT: Do NOT log max history from here anymore.
                    // If you want the set to update MaxRecord silently without history,
                    // you could add a separate repo method; for now we don't touch maxes.

                    // Build a user-facing summary
                    summary = buildString {
                        appendLine("Exercise: $exName ($bodyPart)")
                        appendLine("Sets x Reps: $sets x $reps")
                        append("Total reps: ${sets * reps}")
                    }
                    showDone = true
                }
            }
        ) { Text("Add to session") }

        Spacer(Modifier.height(16.dp))

        Text("Summary")
        Text("Exercises: ${if (exName.isBlank()) 0 else 1}")
        Text("Sets: $sets  |  Reps: ${sets * reps}")
    }
}
