package com.eduvos.gymbuddy.session

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("session")

object SessionManager {
    private val KEY_USER_ID = longPreferencesKey("user_id")

    /** Continuous flow for observing changes */
    fun userIdFlow(context: Context): Flow<Long?> =
        context.dataStore.data.map { it[KEY_USER_ID] }

    /** Set or clear user ID */
    suspend fun setUserId(context: Context, id: Long?) {
        context.dataStore.edit {
            if (id == null) it.remove(KEY_USER_ID)
            else it[KEY_USER_ID] = id
        }
    }

    /** ✅ Added: Fetch current user ID once (used in NavGraph) */
    suspend fun getUserId(context: Context): Long? {
        return userIdFlow(context).first()
    }
}
