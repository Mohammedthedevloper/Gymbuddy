package com.eduvos.gymbuddy.workers
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.eduvos.gymbuddy.data.db.AppDatabase
import java.time.LocalDate
class WeeklyReportWorker(ctx: Context, params: WorkerParameters): CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val db = AppDatabase.get(applicationContext)
        val start = LocalDate.now().minusDays(6).toString()
        val end = LocalDate.now().toString()
        db.workoutDao().let {
            val days = it.trainingDaysInRange(1, start, end)
            val sets = it.totalSetsInRange(1, start, end)
            val reps = it.totalRepsInRange(1, start, end)
            // TODO: Notify user with a summary
        }
        return Result.success()
    }
}
