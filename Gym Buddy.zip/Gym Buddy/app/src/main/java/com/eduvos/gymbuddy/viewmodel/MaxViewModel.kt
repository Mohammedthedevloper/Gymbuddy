package com.eduvos.gymbuddy.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eduvos.gymbuddy.repo.WorkoutRepository
import kotlinx.coroutines.launch
class MaxViewModel(private val repo: WorkoutRepository): ViewModel() {
    fun save(userId: Long, ex: String, rep: Int, w: Float) = viewModelScope.launch { repo.upsertMax(userId, ex, rep, w) }
}
