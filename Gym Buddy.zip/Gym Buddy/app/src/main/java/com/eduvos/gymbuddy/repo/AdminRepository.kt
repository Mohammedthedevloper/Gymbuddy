package com.eduvos.gymbuddy.repo

import com.eduvos.gymbuddy.data.dao.UserDao
import com.eduvos.gymbuddy.data.entity.User

/**
 * Lightweight admin wrapper around UserDao.
 */
class AdminRepository(private val userDao: UserDao) {

    suspend fun users(): List<User> = userDao.all()

    suspend fun block(id: Long) = userDao.block(id)
    suspend fun unblock(id: Long) = userDao.unblock(id)
    suspend fun delete(id: Long) = userDao.delete(id)

    suspend fun verify(id: Long) = userDao.verify(id)
    suspend fun unverify(id: Long) = userDao.unverify(id)
}
